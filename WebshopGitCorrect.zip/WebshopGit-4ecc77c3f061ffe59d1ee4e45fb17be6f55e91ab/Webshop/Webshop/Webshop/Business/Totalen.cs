﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Webshop.Business
{
    public class Totalen
    {
        public double TotExBtw { get; set; }
        public double Btw { get; set; }
        public double TotIncBtw { get; set; }
    }
}